package fishing;

public class FishSpot {
	private Fish fish;

	public FishSpot(Fish fish) {
		this.fish=fish;
	}
	public Fish getFish(){
		return this.fish;
	}
	public String toString(){
		return "���̒ނ��ɂ�"+this.fish.getName()+"�����܂��B";
	}
}
