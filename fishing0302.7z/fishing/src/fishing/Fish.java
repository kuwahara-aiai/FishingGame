package fishing;

public class Fish {
	final private int maguro = 100;
	final private int tai = 120;
	final private int sake = 80;
	final private int buri = 70;
	final private int ika = 30;
	final private int hotate = 20;
	final private int aji = 20;
	final private int medaka = 5;
	final private int gomi = 0;
	final private int ojisan = -50;
	
	public int getMaguro() {
		return maguro;
	}
	public int getTai() {
		return tai;
	}
	public int getSake() {
		return sake;
	}
	public int getBuri() {
		return buri;
	}
	public int getIka() {
		return ika;
	}
	public int getHotate() {
		return hotate;
	}
	public int getAji() {
		return aji;
	}
	public int getMedaka() {
		return medaka;
	}
	public int getGomi() {
		return gomi;
	}
	public int getOjisan() {
		return ojisan;
	}
	public void showFish() {
		int num = ojisan;
		System.out.println(num);
	}
}
